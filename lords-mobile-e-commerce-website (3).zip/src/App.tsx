import { useEffect, useRef, useState, type CSSProperties } from "react";
import AdminPanel from "./AdminPanel";
import type { HubCategory, RssTier, SiteSettings, T1Service } from "./types";

type CartItem = {
  id: string;
  name: string;
  details: string;
  price: string;
  quantity: number;
};

type Theme = "dark" | "bright";

const RSS_TIERS: RssTier[] = [
  {
    name: "K1",
    capacity: "1900K",
    offers: [
      { bundle: "4.4.4.4.4", price: "0.6$" },
      { bundle: "4.4.4.4.2", price: "0.5$" },
      { bundle: "2.2.2.2.2", price: "0.4$" },
      { bundle: "4.4.4.4.0", price: "0.35$" },
      { bundle: "2.2.2.2.0", price: "0.25$" },
      { bundle: "4.0.0.0.0", price: "0.25$" },
    ],
  },
  {
    name: "K1900",
    capacity: "1950K",
    offers: [
      { bundle: "4.4.4.4.4", price: "0.8$" },
      { bundle: "4.4.4.4.2", price: "0.7$" },
      { bundle: "2.2.2.2.2", price: "0.6$" },
      { bundle: "4.4.4.4.0", price: "0.4$" },
      { bundle: "2.2.2.2.0", price: "0.4$" },
      { bundle: "4.0.0.0.0", price: "0.4$" },
    ],
  },
  {
    name: "K2000",
    capacity: "2046K",
    offers: [
      { bundle: "4.4.4.4.2", price: "7$" },
      { bundle: "2.2.2.2.2", price: "6$" },
      { bundle: "4.4.4.4.0", price: "3$" },
      { bundle: "4.0.0.0.0", price: "3$" },
    ],
  },
];

const T1_SERVICES: T1Service[] = [
  {
    id: "manual",
    type: "Manual",
    offers: [
      { amount: "300M", dollars: "2$", inr: "200" },
      { amount: "500M", dollars: "3.5$", inr: "350" },
      { amount: "700M", dollars: "5$", inr: "500" },
      { amount: "1B", dollars: "7$", inr: "700" },
    ],
  },
  {
    id: "automatic",
    type: "Automatic",
    offers: [
      { amount: "500M", dollars: "5$", inr: "500" },
      { amount: "800M", dollars: "8$", inr: "800" },
      { amount: "1B", dollars: "9$", inr: "900" },
    ],
  },
];

const HUB_CATEGORIES: HubCategory[] = [
  {
    id: "automation",
    title: "Automation & Tracking Bots",
    items: ["Farm Bot", "Bank Bot", "Rein Bot", "Tracking Bots", "Help Bot"],
  },
  {
    id: "resources",
    title: "Resources & Supplies",
    items: ["Normal RSS", "Key RSS", "Snowbeast RSS"],
  },
  {
    id: "gems",
    title: "Gems, Passes & Subscriptions",
    items: ["Diamond Pass (Weekly/Monthly)", "Diamonds", "Subscriptions"],
  },
  {
    id: "military",
    title: "Military & Progress",
    items: ["Kills", "Prisoners"],
  },
  {
    id: "accounts",
    title: "Account Marketplace",
    items: ["Account Buy & Sell"],
  },
];

const DEFAULT_SITE_SETTINGS: SiteSettings = {
  brandName: "Lords Mobile",
  brandCaption: "RSS supply",
  skipLinkLabel: "Skip to content",
  navRssLabel: "RSS rates",
  navT1Label: "T1 services",
  navHubLabel: "More services",
  navPaymentLabel: "Payment",
  headerContactLabel: "WhatsApp us",
  heroEyebrow: "Lords Mobile / RSS supply",
  heroTitleTop: "Lords",
  heroTitleBottom: "Mobile",
  heroDescription: "The resources your kingdom needs for its next march.",
  heroPrimaryAction: "Explore RSS",
  heroSecondaryAction: "Order on WhatsApp",
  heroScrollLabel: "Scroll to explore",
  rssEyebrow: "Lords Mobile supply",
  rssTitle: "RSS",
  rssDecoration: "🚀🚀 🚀",
  rssSubtitle: "Choose a pack below and tap its price to order on WhatsApp.",
  moreCombinationsLabel: "More combinations",
  resourceNames: "Food / Stone / Timber / Ore / Gold",
  exchangeRate: "1$ = 100 Rs.",
  t1Eyebrow: "Pirate Trading Hub",
  t1Title: "Official T1 Kills Services",
  t1Intro: "Choose manual or automatic delivery. Tap a package to order through WhatsApp.",
  t1Promise: "Fast delivery | Safe & secure",
  t1Disclaimer: "Prices are subject to change. Contact for more details.",
  hubEyebrow: "Pirate Trading Hub",
  hubTitle: "Deals on the high seas.",
  hubIntro: "Trusted, secure, fast. Add any service to your cart and ask us for a quote on WhatsApp.",
  hubClaim: "Cheapest and most popular worldwide.",
  hubQuoteLabel: "On request",
  hubCartQuoteLabel: "Price on request",
  hubJoinTitle: "Join us now",
  hubJoinLine: "Deal with trusted middlemen.",
  discordLabel: "Discord / Telegram",
  discordInvite: "https://discord.gg/piratehub",
  paymentEyebrow: "Simple, direct payment",
  paymentTitlePrefix: "Pay by",
  paymentTitleAccent: "UPI.",
  paymentIntro: "Pay by UPI using the QR, or use the Binance Pay ID below. Confirm your payment with us on WhatsApp.",
  paymentMethodLabel: "Payment method",
  showUpiPayment: true,
  showBinancePayment: true,
  upiMethodName: "Unified Payments Interface",
  upiTitle: "Scan to pay with UPI",
  upiFallbackTitle: "Get your UPI QR",
  upiDescription: "Scan this QR to pay. Message us on WhatsApp if you need help.",
  upiFallbackDescription: "Request the UPI QR on WhatsApp after confirming your order.",
  upiRequestLabel: "Request UPI QR",
  upiQrImage: "/images/upi-qr.png",
  whatsappNumber: "+91 9115290689",
  binancePayId: "1277923476",
  whatsappContactLabel: "WhatsApp contact",
  binanceContactLabel: "Binance Pay ID",
  footerBrand: "Lords Mobile",
  footerCaption: "RSS supply",
  footerTagline: "Built for kingdoms on the move.",
  footerTopLabel: "Back to top",
  backgrounds: {
    hero: "/images/realm-hero.jpg",
    rss: "/images/resource-backdrop.jpg",
    t1: "/images/pirate-harbor.jpg",
    hub: "/images/resource-backdrop.jpg",
    darkColor: "#111512",
    brightColor: "#f1ebdd",
  },
};

function readSavedValue<T>(key: string, fallback: T): T {
  try {
    const savedValue = window.localStorage.getItem(key);
    return savedValue ? (JSON.parse(savedValue) as T) : fallback;
  } catch {
    return fallback;
  }
}

function makeWhatsAppLink(message: string, phoneNumber: string) {
  const digits = phoneNumber.replace(/\D/g, "") || DEFAULT_SITE_SETTINGS.whatsappNumber.replace(/\D/g, "");
  return `https://wa.me/${digits}?text=${encodeURIComponent(message)}`;
}

function normalizeExternalUrl(value: string) {
  const trimmed = value.trim();
  if (!trimmed) return "#";
  return /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
}

function cssImage(value: string) {
  return value ? `url(${JSON.stringify(value)})` : "none";
}

function ArrowIcon() {
  return (
    <svg aria-hidden="true" viewBox="0 0 20 20" fill="none">
      <path d="M3.5 10h12m-5-5 5 5-5 5" stroke="currentColor" strokeWidth="1.4" />
    </svg>
  );
}

function BagIcon() {
  return (
    <svg aria-hidden="true" viewBox="0 0 24 24" fill="none">
      <path d="M5 8h14l1 13H4L5 8Z" stroke="currentColor" strokeWidth="1.4" />
      <path d="M9 9V6a3 3 0 0 1 6 0v3" stroke="currentColor" strokeWidth="1.4" />
    </svg>
  );
}

function WhatsAppIcon() {
  return (
    <svg className="whatsapp-mark" aria-hidden="true" viewBox="0 0 24 24" fill="none">
      <path d="M20.3 3.7A11.4 11.4 0 0 0 2.5 17.4L1 23l5.7-1.5a11.4 11.4 0 0 0 13.6-17.8Z" stroke="currentColor" strokeWidth="1.5" strokeLinejoin="round" />
      <path d="M8.1 7.3c-.3-.5-.5-.5-.8-.5h-.6c-.2 0-.5.1-.8.4-.3.4-1 1-1 2.4s1.1 2.8 1.3 3c.2.2 2.1 3.3 5.1 4.5 2.5 1 3 .8 3.5.7.5-.1 1.7-.7 2-1.4.2-.7.2-1.3.2-1.4-.1-.2-.3-.3-.6-.4l-2-.9c-.3-.1-.5-.2-.7.2-.2.3-.8.9-1 1.1-.2.2-.4.2-.7.1-.3-.2-1.3-.5-2.5-1.5-.9-.8-1.5-1.8-1.7-2.1-.2-.3 0-.5.1-.7.2-.1.4-.4.5-.5.2-.2.2-.4.4-.6.1-.2 0-.4 0-.6l-.9-2.1Z" fill="currentColor" />
    </svg>
  );
}

function ThemeIcon({ bright }: { bright: boolean }) {
  return bright ? (
    <svg aria-hidden="true" viewBox="0 0 24 24" fill="none">
      <path d="M20.5 15.5A8.5 8.5 0 0 1 8.5 3.5a8.5 8.5 0 1 0 12 12Z" stroke="currentColor" strokeWidth="1.5" />
    </svg>
  ) : (
    <svg aria-hidden="true" viewBox="0 0 24 24" fill="none">
      <circle cx="12" cy="12" r="3.5" stroke="currentColor" strokeWidth="1.5" />
      <path d="M12 2v2m0 16v2M4.93 4.93l1.42 1.42m11.3 11.3 1.42 1.42M2 12h2m16 0h2M4.93 19.07l1.42-1.42m11.3-11.3 1.42-1.42" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    </svg>
  );
}

function AdminIcon() {
  return (
    <svg aria-hidden="true" viewBox="0 0 24 24" fill="none">
      <circle cx="12" cy="12" r="3" stroke="currentColor" strokeWidth="1.5" />
      <path d="M12 2.8v2m0 14.4v2M2.8 12h2m14.4 0h2M5.5 5.5l1.4 1.4m10.2 10.2 1.4 1.4m0-13-1.4 1.4M6.9 17.1l-1.4 1.4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    </svg>
  );
}

export default function App() {
  const [theme, setTheme] = useState<Theme>(() => {
    try {
      return window.localStorage.getItem("lords-mobile-theme") === "bright" ? "bright" : "dark";
    } catch {
      return "dark";
    }
  });
  const [siteSettings, setSiteSettings] = useState<SiteSettings>(() => readSavedValue("pirate-site-settings", DEFAULT_SITE_SETTINGS));
  const [rssTiers, setRssTiers] = useState<RssTier[]>(() => readSavedValue("pirate-rss-tiers", RSS_TIERS));
  const [t1Services, setT1Services] = useState<T1Service[]>(() => readSavedValue("pirate-t1-services", T1_SERVICES));
  const [hubCategories, setHubCategories] = useState<HubCategory[]>(() => readSavedValue("pirate-hub-categories", HUB_CATEGORIES));
  const [copyLabel, setCopyLabel] = useState("Copy number");
  const [binanceCopyLabel, setBinanceCopyLabel] = useState("Copy ID");
  const [upiQrUnavailable, setUpiQrUnavailable] = useState(false);
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [adminOpen, setAdminOpen] = useState(false);
  const [lastAddedId, setLastAddedId] = useState<string | null>(null);
  const cartButtonRef = useRef<HTMLButtonElement>(null);
  const closeCartButtonRef = useRef<HTMLButtonElement>(null);

  const whatsappLink = (message: string) => makeWhatsAppLink(message, siteSettings.whatsappNumber);
  const siteBackgroundStyle = {
    "--hero-background-image": cssImage(siteSettings.backgrounds.hero),
    "--resources-background-image": cssImage(siteSettings.backgrounds.rss),
    "--t1-background-image": cssImage(siteSettings.backgrounds.t1),
    "--hub-background-image": cssImage(siteSettings.backgrounds.hub),
    "--site-dark-color": siteSettings.backgrounds.darkColor,
    "--site-bright-color": siteSettings.backgrounds.brightColor,
  } as CSSProperties;

  const cartCount = cartItems.reduce((total, item) => total + item.quantity, 0);
  const cartMessage = [
    `Hi, I would like to place this ${siteSettings.brandName} order:`,
    ...cartItems.map(
      (item) => `- ${item.name} | ${item.details} | quantity ${item.quantity} | ${item.price} each`
    ),
    "Please confirm availability and the final total.",
  ].join("\n");
  const cartWhatsAppLink = whatsappLink(cartMessage);

  const paymentLink = whatsappLink(`Hi, I would like to pay for my ${siteSettings.brandName} order using UPI. Please share the payment QR.`);

  useEffect(() => {
    try {
      window.localStorage.setItem("lords-mobile-theme", theme);
    } catch {
      // Keep the theme usable when storage is unavailable.
    }
  }, [theme]);

  useEffect(() => {
    try {
      window.localStorage.setItem("pirate-rss-tiers", JSON.stringify(rssTiers));
      window.localStorage.setItem("pirate-t1-services", JSON.stringify(t1Services));
      window.localStorage.setItem("pirate-hub-categories", JSON.stringify(hubCategories));
      window.localStorage.setItem("pirate-site-settings", JSON.stringify(siteSettings));
    } catch {
      // Keep the catalog usable when storage is unavailable.
    }
  }, [rssTiers, t1Services, hubCategories, siteSettings]);

  useEffect(() => {
    setUpiQrUnavailable(false);
  }, [siteSettings.upiQrImage]);

  useEffect(() => {
    if (!adminOpen) return;

    const previousOverflow = document.body.style.overflow;
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") setAdminOpen(false);
    };

    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", closeOnEscape);

    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener("keydown", closeOnEscape);
    };
  }, [adminOpen]);

  useEffect(() => {
    if (!cartOpen) return;

    const previousOverflow = document.body.style.overflow;
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") setCartOpen(false);
    };

    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", closeOnEscape);
    closeCartButtonRef.current?.focus();

    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener("keydown", closeOnEscape);
      cartButtonRef.current?.focus();
    };
  }, [cartOpen]);

  function addToCart(item: Omit<CartItem, "quantity">) {
    setCartItems((currentItems) => {
      const existingItem = currentItems.find((cartItem) => cartItem.id === item.id);

      if (existingItem) {
        return currentItems.map((cartItem) =>
          cartItem.id === item.id ? { ...cartItem, quantity: cartItem.quantity + 1 } : cartItem
        );
      }

      return [...currentItems, { ...item, quantity: 1 }];
    });

    setLastAddedId(item.id);
    window.setTimeout(() => {
      setLastAddedId((currentId) => (currentId === item.id ? null : currentId));
    }, 1400);
  }

  function adjustCartQuantity(id: string, change: -1 | 1) {
    setCartItems((currentItems) =>
      currentItems.flatMap((item) => {
        if (item.id !== id) return [item];
        const quantity = item.quantity + change;
        return quantity > 0 ? [{ ...item, quantity }] : [];
      })
    );
  }

  async function copyWhatsAppNumber() {
    try {
      await navigator.clipboard.writeText(siteSettings.whatsappNumber);
      setCopyLabel("Number copied");
      window.setTimeout(() => setCopyLabel("Copy number"), 2200);
    } catch {
      window.open(whatsappLink(`Hi, I would like to get in touch about ${siteSettings.brandName} RSS.`), "_blank", "noopener,noreferrer");
    }
  }

  async function copyBinancePayId() {
    try {
      await navigator.clipboard.writeText(siteSettings.binancePayId);
      setBinanceCopyLabel("ID copied");
      window.setTimeout(() => setBinanceCopyLabel("Copy ID"), 2200);
    } catch {
      setBinanceCopyLabel("Select ID");
    }
  }

  return (
    <div className={`site-shell${theme === "bright" ? " theme-bright" : ""}`} style={siteBackgroundStyle}>
      <a className="skip-link" href="#main-content">
        {siteSettings.skipLinkLabel}
      </a>

      <header className="site-header">
        <div className="header-inner">
          <a className="brand-lockup" href="#top" aria-label={`${siteSettings.brandName} ${siteSettings.brandCaption} home`}>
            <span className="brand-crest" aria-hidden="true">
              <span />
            </span>
            <span className="brand-copy">
              <span className="brand-name">{siteSettings.brandName}</span>
              <span className="brand-caption">{siteSettings.brandCaption}</span>
            </span>
          </a>

          <nav className="site-nav" aria-label="Main navigation">
            <a href="#rss">{siteSettings.navRssLabel}</a>
            <a href="#t1-kills">{siteSettings.navT1Label}</a>
            <a href="#hub-services">{siteSettings.navHubLabel}</a>
            <a href="#payment">{siteSettings.navPaymentLabel}</a>
          </nav>

          <div className="header-actions">
            <button
              className="admin-top-trigger"
              type="button"
              aria-label="Open admin panel"
              title="Admin panel"
              onClick={() => setAdminOpen(true)}
            >
              <AdminIcon />
              <span>Admin</span>
            </button>
            <button
              className="theme-toggle"
              type="button"
              aria-label={`Switch to ${theme === "dark" ? "bright" : "dark"} color theme`}
              aria-pressed={theme === "bright"}
              onClick={() => setTheme((currentTheme) => (currentTheme === "dark" ? "bright" : "dark"))}
            >
              <ThemeIcon bright={theme === "bright"} />
              <span className="theme-toggle-label">{theme === "dark" ? "Bright" : "Dark"}</span>
            </button>
            <button
              className="cart-trigger"
              type="button"
              ref={cartButtonRef}
              aria-label={`Open cart, ${cartCount} item${cartCount === 1 ? "" : "s"}`}
              aria-haspopup="dialog"
              aria-expanded={cartOpen}
              onClick={() => setCartOpen(true)}
            >
              <BagIcon />
              <span className="cart-count" aria-hidden="true">{cartCount}</span>
            </button>
            <a
              className="header-contact"
              aria-label={siteSettings.headerContactLabel}
              href={whatsappLink(`Hi, I would like to enquire about ${siteSettings.brandName} RSS.`)}
              target="_blank"
              rel="noreferrer"
            >
              <span className="header-contact-label">{siteSettings.headerContactLabel}</span>
              <WhatsAppIcon />
              <ArrowIcon />
            </a>
          </div>
        </div>
      </header>

      <main id="main-content">
        <section className="hero" id="top" aria-labelledby="hero-title">
          <div className="hero-content page-width">
            <p className="eyebrow hero-eyebrow">
              <span className="eyebrow-rule" /> {siteSettings.heroEyebrow}
            </p>
            <h1 id="hero-title">
              {siteSettings.heroTitleTop}
              <span>{siteSettings.heroTitleBottom}</span>
            </h1>
            <p className="hero-description">
              {siteSettings.heroDescription}
            </p>
            <div className="hero-actions">
              <a className="button button-gold" href="#rss">
                {siteSettings.heroPrimaryAction}
                <ArrowIcon />
              </a>
              <a
                className="button button-quiet"
                href={whatsappLink(`Hi, I would like to enquire about ${siteSettings.brandName} RSS.`)}
                target="_blank"
                rel="noreferrer"
              >
                {siteSettings.heroSecondaryAction}
              </a>
            </div>
          </div>
          <a className="hero-scroll" href="#rss" aria-label="Scroll to RSS resources">
            <span className="scroll-line" />
            <span>{siteSettings.heroScrollLabel}</span>
          </a>
        </section>

        <section className="resources-section" id="rss" aria-labelledby="rss-title">
          <div className="resources-shade" aria-hidden="true" />
          <div className="resources-inner page-width">
            <div className="resources-heading">
              <p className="eyebrow">
                <span className="eyebrow-rule" /> {siteSettings.rssEyebrow}
              </p>
              <h2 id="rss-title">{siteSettings.rssTitle} <span className="rss-title-emoji">{siteSettings.rssDecoration}</span></h2>
              <p className="section-intro">{siteSettings.rssSubtitle}</p>
              <p className="rss-name-list" aria-label="Resource names">{siteSettings.resourceNames}</p>
              <p className="exchange-rate-note">Exchange rate: {siteSettings.exchangeRate}</p>
            </div>

            <div className="rate-tiers">
              {rssTiers.map((tier, tierIndex) => (
                <article className="rate-tier" key={`${tierIndex}-${tier.name}`}>
                  <div className="rate-tier-heading">
                    <h3>{tier.name}</h3>
                    <p>
                      <span aria-hidden="true">✈️</span>
                      <span>~ {tier.capacity}</span>
                      <span aria-hidden="true">✈️</span>
                    </p>
                  </div>

                  <div className="rate-list">
                    {tier.offers.map((offer, offerIndex) => {
                      const cartItem = {
                        id: `rss-${tierIndex}-${offerIndex}`,
                        name: `${siteSettings.brandName} RSS`,
                        details: `${tier.name} (~ ${tier.capacity}) / ${offer.bundle}`,
                        price: offer.price,
                      };

                      return (
                        <div
                          className="rate-row"
                          key={`${tierIndex}-${offerIndex}`}
                        >
                          <span className="rate-bundle">{offer.bundle}</span>
                          <span className="rate-separator" aria-hidden="true">»</span>
                          <span className="rate-price">{offer.price}</span>
                          <button
                            className={`add-cart-button${lastAddedId === cartItem.id ? " is-added" : ""}`}
                            type="button"
                            aria-label={`Add ${tier.name} ${offer.bundle} RSS pack to cart for ${offer.price}`}
                            onClick={() => addToCart(cartItem)}
                          >
                            {lastAddedId === cartItem.id ? "Added" : "+ Add"}
                          </button>
                        </div>
                      );
                    })}
                  </div>

                  <a
                    className="tier-more-link"
                    href={whatsappLink(`Hi, please share more ${tier.name} ${siteSettings.brandName} RSS combinations.`)}
                    target="_blank"
                    rel="noreferrer"
                  >
                    {siteSettings.moreCombinationsLabel}
                    <ArrowIcon />
                  </a>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="t1-section" id="t1-kills" aria-labelledby="t1-title">
          <div className="t1-backdrop" aria-hidden="true" />
          <div className="t1-shade" aria-hidden="true" />
          <div className="t1-inner page-width">
            <div className="t1-heading">
              <p className="eyebrow">
                <span className="eyebrow-rule" /> {siteSettings.t1Eyebrow}
              </p>
              <h2 id="t1-title">{siteSettings.t1Title}</h2>
              <p className="t1-intro">{siteSettings.t1Intro}</p>
            </div>

            <div className="t1-services">
              {t1Services.map((service, serviceIndex) => (
                <article className={`t1-service ${service.id}`} key={`${service.id}-${serviceIndex}`} aria-labelledby={`${service.id}-title`}>
                  <div className="t1-service-heading">
                    <p>{service.type} service</p>
                    <h3 id={`${service.id}-title`}>
                      {service.type} <span>T1 Kills</span>
                    </h3>
                  </div>

                  <div className="t1-price-list">
                    {service.offers.map((offer, offerIndex) => {
                      const cartItem = {
                        id: `t1-${service.id}-${offerIndex}`,
                        name: `${service.type} T1 Kills`,
                        details: offer.amount,
                        price: `${offer.dollars} / ${offer.inr} INR`,
                      };

                      return (
                        <div
                          className="t1-price-row"
                          key={`${service.id}-${offerIndex}`}
                        >
                          <span className="t1-amount">{offer.amount}</span>
                          <span className="t1-price">
                            {offer.dollars} <span>-</span> {offer.inr} /- INR
                          </span>
                          <button
                            className={`add-cart-button${lastAddedId === cartItem.id ? " is-added" : ""}`}
                            type="button"
                            aria-label={`Add ${service.type} T1 Kills ${offer.amount} to cart for ${offer.dollars} and ${offer.inr} INR`}
                            onClick={() => addToCart(cartItem)}
                          >
                            {lastAddedId === cartItem.id ? "Added" : "+ Add"}
                          </button>
                        </div>
                      );
                    })}
                  </div>
                </article>
              ))}
            </div>

            <div className="t1-promise">{siteSettings.t1Promise}</div>
            <p className="t1-disclaimer">{siteSettings.t1Disclaimer}</p>
            <p className="exchange-rate-note t1-exchange-note">Exchange rate: {siteSettings.exchangeRate}</p>
          </div>
        </section>

        <section className="hub-services-section" id="hub-services" aria-labelledby="hub-services-title">
          <div className="hub-services-backdrop" aria-hidden="true" />
          <div className="hub-services-shade" aria-hidden="true" />
          <div className="hub-services-inner page-width">
            <div className="hub-services-heading">
              <p className="eyebrow">
                <span className="eyebrow-rule" /> {siteSettings.hubEyebrow}
              </p>
              <h2 id="hub-services-title">{siteSettings.hubTitle}</h2>
              <p className="hub-services-intro">{siteSettings.hubIntro}</p>
              <p className="hub-worldwide-claim">{siteSettings.hubClaim}</p>
            </div>

            <div className="hub-category-grid">
              {hubCategories.map((category, categoryIndex) => (
                <article className="hub-category" key={`${category.id}-${categoryIndex}`}>
                  <h3>{category.title}</h3>
                  <div className="hub-service-list">
                    {category.items.map((item, index) => {
                      const cartItem = {
                        id: `hub-${category.id}-${index}`,
                        name: item,
                        details: category.title,
                        price: siteSettings.hubCartQuoteLabel,
                      };

                      return (
                        <div className="hub-service-row" key={item}>
                          <span className="hub-item-name">{item}</span>
                          <span className="hub-item-price">{siteSettings.hubQuoteLabel}</span>
                          <button
                            className={`add-cart-button${lastAddedId === cartItem.id ? " is-added" : ""}`}
                            type="button"
                            aria-label={`Add ${item} to cart`}
                            onClick={() => addToCart(cartItem)}
                          >
                            {lastAddedId === cartItem.id ? "Added" : "+ Add"}
                          </button>
                        </div>
                      );
                    })}
                  </div>
                </article>
              ))}
            </div>

            <div className="hub-community">
              <div className="hub-community-copy">
                <p>{siteSettings.hubJoinTitle}</p>
                <span>{siteSettings.hubJoinLine}</span>
              </div>
              <a className="hub-community-link" href={normalizeExternalUrl(siteSettings.discordInvite)} target="_blank" rel="noreferrer">
                <span className="hub-community-service">{siteSettings.discordLabel}</span>
                <span className="hub-community-address">{siteSettings.discordInvite}</span>
                <ArrowIcon />
              </a>
              <a
                className="hub-community-link"
                href={whatsappLink(`Hi, I would like to ask about ${siteSettings.hubEyebrow} services.`)}
                target="_blank"
                rel="noreferrer"
              >
                <span className="hub-community-service">{siteSettings.headerContactLabel}</span>
                <span className="hub-community-address">{siteSettings.whatsappNumber}</span>
                <ArrowIcon />
              </a>
            </div>
          </div>
        </section>

        <section className="payment-section" id="payment" aria-labelledby="payment-title">
          <div className="payment-inner page-width">
            <div className="payment-copy">
              <p className="eyebrow dark-eyebrow">
                <span className="eyebrow-rule" /> {siteSettings.paymentEyebrow}
              </p>
              <h2 id="payment-title">
                {siteSettings.paymentTitlePrefix} <em>{siteSettings.paymentTitleAccent}</em>
              </h2>
              <p className="payment-intro">{siteSettings.paymentIntro}</p>
            </div>

            <div className="payment-panel">
              <div className="payment-panel-top">
                <div className="upi-mark" aria-hidden="true">{siteSettings.showUpiPayment ? "UPI" : "PAY"}</div>
                <div className="payment-method-copy">
                  <span className="panel-kicker">{siteSettings.paymentMethodLabel}</span>
                  <strong>
                    {siteSettings.showUpiPayment
                      ? siteSettings.upiMethodName
                      : siteSettings.showBinancePayment
                        ? siteSettings.binanceContactLabel
                        : "Contact us to pay"}
                  </strong>
                </div>
              </div>

              <div className="payment-divider" />

              {siteSettings.showUpiPayment && (
                <>
                  <div className="payment-request">
                    <div className="payment-qr-frame">
                      {upiQrUnavailable || !siteSettings.upiQrImage ? (
                        <div className="upi-qr-fallback">
                          <span>UPI</span>
                          <small>QR available on WhatsApp</small>
                        </div>
                      ) : (
                        <a className="upi-qr-link" href={siteSettings.upiQrImage} target="_blank" rel="noreferrer">
                          <img
                            className="upi-qr-image"
                            src={siteSettings.upiQrImage}
                            alt="Scan this UPI payment QR code"
                            onError={() => setUpiQrUnavailable(true)}
                          />
                        </a>
                      )}
                    </div>
                    <div className="payment-request-copy">
                      <h3>{upiQrUnavailable || !siteSettings.upiQrImage ? siteSettings.upiFallbackTitle : siteSettings.upiTitle}</h3>
                      <p>
                        {upiQrUnavailable || !siteSettings.upiQrImage
                          ? siteSettings.upiFallbackDescription
                          : siteSettings.upiDescription}
                      </p>
                      <a className="payment-link" href={paymentLink} target="_blank" rel="noreferrer">
                        {siteSettings.upiRequestLabel}
                        <ArrowIcon />
                      </a>
                    </div>
                  </div>
                  <div className="payment-divider lower-divider" />
                </>
              )}

              <div className="payment-contact">
                <div className="contact-copy">
                  <span className="panel-kicker">{siteSettings.whatsappContactLabel}</span>
                  <a href={whatsappLink(`Hi, I would like to get in touch about ${siteSettings.brandName} RSS.`)} target="_blank" rel="noreferrer">
                    {siteSettings.whatsappNumber}
                  </a>
                </div>
                <button className="copy-button" type="button" onClick={copyWhatsAppNumber}>
                  {copyLabel}
                </button>
              </div>

              {siteSettings.showBinancePayment && (
                <>
                  <div className="payment-divider lower-divider" />
                  <div className="payment-contact">
                    <div className="contact-copy">
                      <span className="panel-kicker">{siteSettings.binanceContactLabel}</span>
                      <span className="payment-reference" title="Select to copy">{siteSettings.binancePayId}</span>
                    </div>
                    <button
                      className="copy-button"
                      type="button"
                      aria-label="Copy Binance Pay ID"
                      onClick={copyBinancePayId}
                    >
                      {binanceCopyLabel}
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </section>
      </main>

      <footer className="site-footer">
        <div className="footer-inner page-width">
          <a className="footer-brand" href="#top">{siteSettings.footerBrand} <span>{siteSettings.footerCaption}</span></a>
          <p>{siteSettings.footerTagline}</p>
          <a className="footer-top-link" href="#top">{siteSettings.footerTopLabel} <ArrowIcon /></a>
        </div>
      </footer>

      {adminOpen && (
        <AdminPanel
          rssTiers={rssTiers}
          t1Services={t1Services}
          hubCategories={hubCategories}
          siteSettings={siteSettings}
          onRssTiersChange={setRssTiers}
          onT1ServicesChange={setT1Services}
          onHubCategoriesChange={setHubCategories}
          onSiteSettingsChange={setSiteSettings}
          onReset={() => {
            setRssTiers(RSS_TIERS.map((tier) => ({ ...tier, offers: tier.offers.map((offer) => ({ ...offer })) })));
            setT1Services(T1_SERVICES.map((service) => ({ ...service, offers: service.offers.map((offer) => ({ ...offer })) })));
            setHubCategories(HUB_CATEGORIES.map((category) => ({ ...category, items: [...category.items] })));
            setSiteSettings({ ...DEFAULT_SITE_SETTINGS, backgrounds: { ...DEFAULT_SITE_SETTINGS.backgrounds } });
          }}
          onClose={() => setAdminOpen(false)}
        />
      )}

      {cartOpen && (
        <div className="cart-layer">
          <button
            className="cart-scrim"
            type="button"
            aria-label="Close cart"
            onClick={() => setCartOpen(false)}
          />
          <aside className="cart-drawer" role="dialog" aria-modal="true" aria-labelledby="cart-title">
            <div className="cart-drawer-header">
              <div>
                <p className="cart-kicker">Your order list</p>
                <h2 id="cart-title">Cart <span>{cartCount}</span></h2>
              </div>
              <button
                className="cart-close"
                type="button"
                ref={closeCartButtonRef}
                onClick={() => setCartOpen(false)}
              >
                Close
              </button>
            </div>

            {cartItems.length === 0 ? (
              <div className="cart-empty">
                <p className="cart-kicker">Nothing added yet</p>
                <h3>Build your order list.</h3>
                <p>Add any RSS or T1 Kills offer. Your selected options will appear here.</p>
                <button className="cart-continue" type="button" onClick={() => setCartOpen(false)}>
                  Continue shopping
                </button>
              </div>
            ) : (
              <>
                <div className="cart-lines" aria-live="polite">
                  {cartItems.map((item) => (
                    <article className="cart-line" key={item.id}>
                      <div className="cart-line-copy">
                        <h3>{item.name}</h3>
                        <p className="cart-line-details">{item.details}</p>
                        <p className="cart-line-price">{item.price} each</p>
                      </div>
                      <div className="cart-quantity" aria-label={`Quantity for ${item.name}, ${item.details}`}>
                        <button
                          type="button"
                          aria-label={`Remove one ${item.name}, ${item.details}`}
                          onClick={() => adjustCartQuantity(item.id, -1)}
                        >
                          -
                        </button>
                        <span>{item.quantity}</span>
                        <button
                          type="button"
                          aria-label={`Add one ${item.name}, ${item.details}`}
                          onClick={() => adjustCartQuantity(item.id, 1)}
                        >
                          +
                        </button>
                      </div>
                    </article>
                  ))}
                </div>
                <div className="cart-footer">
                  <p className="cart-order-note">
                    <span className="cart-rate-highlight">Exchange rate: {siteSettings.exchangeRate}</span>
                    <span>Confirm the final total on WhatsApp.</span>
                  </p>
                  <a className="cart-send" href={cartWhatsAppLink} target="_blank" rel="noreferrer">
                    <span>Send order list to WhatsApp</span>
                    <ArrowIcon />
                  </a>
                  <button className="cart-clear" type="button" onClick={() => setCartItems([])}>
                    Clear cart
                  </button>
                </div>
              </>
            )}
          </aside>
        </div>
      )}
    </div>
  );
}