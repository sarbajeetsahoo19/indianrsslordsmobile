import { useState, type ChangeEvent, type FormEvent } from "react";
import type { HubCategory, RssTier, SiteBackgrounds, SiteSettings, T1Service } from "./types";

type AdminTab = "rss" | "t1" | "hub" | "site" | "payments";
type TextSettingKey = Exclude<keyof SiteSettings, "backgrounds" | "showUpiPayment" | "showBinancePayment">;

const SETTING_GROUPS: { title: string; fields: { key: TextSettingKey; label: string; multiline?: boolean }[] }[] = [
  {
    title: "Brand and navigation",
    fields: [
      { key: "brandName", label: "Brand name" },
      { key: "brandCaption", label: "Brand caption" },
      { key: "skipLinkLabel", label: "Accessibility skip link" },
      { key: "navRssLabel", label: "RSS navigation label" },
      { key: "navT1Label", label: "T1 navigation label" },
      { key: "navHubLabel", label: "Hub navigation label" },
      { key: "navPaymentLabel", label: "Payment navigation label" },
      { key: "headerContactLabel", label: "Header contact label" },
    ],
  },
  {
    title: "Hero section",
    fields: [
      { key: "heroEyebrow", label: "Eyebrow" },
      { key: "heroTitleTop", label: "Headline first line" },
      { key: "heroTitleBottom", label: "Headline second line" },
      { key: "heroDescription", label: "Supporting text", multiline: true },
      { key: "heroPrimaryAction", label: "Primary button" },
      { key: "heroSecondaryAction", label: "WhatsApp button" },
      { key: "heroScrollLabel", label: "Scroll label" },
    ],
  },
  {
    title: "RSS section",
    fields: [
      { key: "rssEyebrow", label: "Eyebrow" },
      { key: "rssTitle", label: "Title" },
      { key: "rssDecoration", label: "Title decoration" },
      { key: "rssSubtitle", label: "Supporting text", multiline: true },
      { key: "resourceNames", label: "Resource names" },
      { key: "exchangeRate", label: "Exchange rate note" },
      { key: "moreCombinationsLabel", label: "More combinations link" },
    ],
  },
  {
    title: "T1 services section",
    fields: [
      { key: "t1Eyebrow", label: "Eyebrow" },
      { key: "t1Title", label: "Title" },
      { key: "t1Intro", label: "Supporting text", multiline: true },
      { key: "t1Promise", label: "Delivery and safety line" },
      { key: "t1Disclaimer", label: "Price disclaimer" },
    ],
  },
  {
    title: "Trading Hub section",
    fields: [
      { key: "hubEyebrow", label: "Eyebrow" },
      { key: "hubTitle", label: "Title" },
      { key: "hubIntro", label: "Supporting text", multiline: true },
      { key: "hubClaim", label: "Promotional claim" },
      { key: "hubQuoteLabel", label: "Service quote label" },
      { key: "hubCartQuoteLabel", label: "Cart quote label" },
      { key: "hubJoinTitle", label: "Community heading" },
      { key: "hubJoinLine", label: "Community description" },
      { key: "discordLabel", label: "Community link label" },
      { key: "discordInvite", label: "Discord invite URL" },
    ],
  },
  {
    title: "Footer",
    fields: [
      { key: "footerBrand", label: "Footer brand" },
      { key: "footerCaption", label: "Footer caption" },
      { key: "footerTagline", label: "Footer tagline" },
      { key: "footerTopLabel", label: "Back-to-top link" },
    ],
  },
];

const PAYMENT_SETTING_GROUPS: { title: string; fields: { key: TextSettingKey; label: string; multiline?: boolean }[] }[] = [
  {
    title: "Payment section copy",
    fields: [
      { key: "paymentEyebrow", label: "Eyebrow" },
      { key: "paymentTitlePrefix", label: "Headline prefix" },
      { key: "paymentTitleAccent", label: "Headline accent" },
      { key: "paymentIntro", label: "Payment description", multiline: true },
      { key: "paymentMethodLabel", label: "Method label" },
    ],
  },
  {
    title: "UPI",
    fields: [
      { key: "upiMethodName", label: "UPI method name" },
      { key: "upiTitle", label: "UPI heading" },
      { key: "upiFallbackTitle", label: "Fallback heading" },
      { key: "upiDescription", label: "UPI instructions", multiline: true },
      { key: "upiFallbackDescription", label: "Fallback instructions", multiline: true },
      { key: "upiRequestLabel", label: "QR request button" },
      { key: "upiQrImage", label: "QR image URL or path" },
    ],
  },
  {
    title: "Binance Pay and WhatsApp",
    fields: [
      { key: "binancePayId", label: "Binance Pay ID" },
      { key: "binanceContactLabel", label: "Binance label" },
      { key: "whatsappNumber", label: "WhatsApp number" },
      { key: "whatsappContactLabel", label: "WhatsApp label" },
    ],
  },
];

const BACKGROUND_FIELDS: { key: keyof SiteBackgrounds; label: string }[] = [
  { key: "hero", label: "Hero background" },
  { key: "rss", label: "RSS background" },
  { key: "t1", label: "T1 background" },
  { key: "hub", label: "Trading Hub background" },
];

type AdminPanelProps = {
  rssTiers: RssTier[];
  t1Services: T1Service[];
  hubCategories: HubCategory[];
  siteSettings: SiteSettings;
  onRssTiersChange: (next: RssTier[]) => void;
  onT1ServicesChange: (next: T1Service[]) => void;
  onHubCategoriesChange: (next: HubCategory[]) => void;
  onSiteSettingsChange: (next: SiteSettings) => void;
  onReset: () => void;
  onClose: () => void;
};

const ADMIN_PASSWORD = "PIRATEXRAM";

function makeId(prefix: string) {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
}

function compressBackgroundImage(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const objectUrl = URL.createObjectURL(file);
    const image = new Image();

    image.onload = () => {
      const maxDimension = 1800;
      const scale = Math.min(1, maxDimension / Math.max(image.naturalWidth, image.naturalHeight));
      const canvas = document.createElement("canvas");
      canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
      canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
      const context = canvas.getContext("2d");
      URL.revokeObjectURL(objectUrl);

      if (!context) {
        reject(new Error("Could not process this image."));
        return;
      }

      context.drawImage(image, 0, 0, canvas.width, canvas.height);
      resolve(canvas.toDataURL("image/jpeg", 0.82));
    };

    image.onerror = () => {
      URL.revokeObjectURL(objectUrl);
      reject(new Error("Could not read this image."));
    };
    image.src = objectUrl;
  });
}

function readImageData(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => typeof reader.result === "string" ? resolve(reader.result) : reject(new Error("Could not read this image."));
    reader.onerror = () => reject(new Error("Could not read this image."));
    reader.readAsDataURL(file);
  });
}

export default function AdminPanel({
  rssTiers,
  t1Services,
  hubCategories,
  siteSettings,
  onRssTiersChange,
  onT1ServicesChange,
  onHubCategoriesChange,
  onSiteSettingsChange,
  onReset,
  onClose,
}: AdminPanelProps) {
  const [unlocked, setUnlocked] = useState(false);
  const [activeTab, setActiveTab] = useState<AdminTab>("rss");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [uploadMessage, setUploadMessage] = useState("");

  function updateSetting(key: TextSettingKey, value: string) {
    onSiteSettingsChange({ ...siteSettings, [key]: value });
  }

  function updatePaymentVisibility(key: "showUpiPayment" | "showBinancePayment", value: boolean) {
    onSiteSettingsChange({ ...siteSettings, [key]: value });
  }

  function renderSettingsFields(fields: { key: TextSettingKey; label: string; multiline?: boolean }[]) {
    return (
      <div className="admin-settings-grid">
        {fields.map((field) => (
          <label className={`admin-field${field.multiline ? " admin-field-wide" : ""}`} key={field.key}>
            {field.label}
            {field.multiline ? (
              <textarea
                rows={3}
                value={siteSettings[field.key]}
                onChange={(event) => updateSetting(field.key, event.target.value)}
              />
            ) : (
              <input
                value={siteSettings[field.key]}
                onChange={(event) => updateSetting(field.key, event.target.value)}
              />
            )}
          </label>
        ))}
      </div>
    );
  }

  function updateBackground(key: keyof SiteBackgrounds, value: string) {
    onSiteSettingsChange({
      ...siteSettings,
      backgrounds: { ...siteSettings.backgrounds, [key]: value },
    });
  }

  async function uploadBackground(key: keyof SiteBackgrounds, event: ChangeEvent<HTMLInputElement>) {
    const input = event.currentTarget;
    const file = input.files?.[0];
    if (!file) return;

    try {
      updateBackground(key, await compressBackgroundImage(file));
      setUploadMessage("Background updated.");
    } catch {
      setUploadMessage("Could not process that background image.");
    } finally {
      input.value = "";
    }
  }

  async function uploadQrImage(event: ChangeEvent<HTMLInputElement>) {
    const input = event.currentTarget;
    const file = input.files?.[0];
    if (!file) return;
    if (file.size > 1_500_000) {
      setUploadMessage("Choose a QR image smaller than 1.5 MB to fit browser storage.");
      input.value = "";
      return;
    }

    try {
      updateSetting("upiQrImage", await readImageData(file));
      setUploadMessage("UPI QR image updated.");
    } catch {
      setUploadMessage("Could not read that QR image.");
    } finally {
      input.value = "";
    }
  }

  function unlockAdmin(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (password === ADMIN_PASSWORD) {
      setUnlocked(true);
      setError("");
      return;
    }
    setPassword("");
    setError("That password did not match.");
  }

  function updateRssTier(index: number, field: "name" | "capacity", value: string) {
    onRssTiersChange(rssTiers.map((tier, tierIndex) =>
      tierIndex === index ? { ...tier, [field]: value } : tier
    ));
  }

  function updateRssOffer(tierIndex: number, offerIndex: number, field: "bundle" | "price", value: string) {
    onRssTiersChange(rssTiers.map((tier, index) => index === tierIndex
      ? {
          ...tier,
          offers: tier.offers.map((offer, itemIndex) =>
            itemIndex === offerIndex ? { ...offer, [field]: value } : offer
          ),
        }
      : tier
    ));
  }

  function updateT1Service(index: number, value: string) {
    onT1ServicesChange(t1Services.map((service, serviceIndex) =>
      serviceIndex === index ? { ...service, type: value } : service
    ));
  }

  function updateT1Offer(serviceIndex: number, offerIndex: number, field: "amount" | "dollars" | "inr", value: string) {
    onT1ServicesChange(t1Services.map((service, index) => index === serviceIndex
      ? {
          ...service,
          offers: service.offers.map((offer, itemIndex) =>
            itemIndex === offerIndex ? { ...offer, [field]: value } : offer
          ),
        }
      : service
    ));
  }

  function updateHubCategory(index: number, value: string) {
    onHubCategoriesChange(hubCategories.map((category, categoryIndex) =>
      categoryIndex === index ? { ...category, title: value } : category
    ));
  }

  function updateHubItem(categoryIndex: number, itemIndex: number, value: string) {
    onHubCategoriesChange(hubCategories.map((category, index) => index === categoryIndex
      ? {
          ...category,
          items: category.items.map((item, currentIndex) => currentIndex === itemIndex ? value : item),
        }
      : category
    ));
  }

  function confirmReset() {
    if (window.confirm("Reset all catalog content and site settings to their original values?")) onReset();
  }

  return (
    <div className="admin-layer">
      <button className="admin-scrim" type="button" aria-label="Close admin panel" onClick={onClose} />
      <aside className="admin-drawer" role="dialog" aria-modal="true" aria-labelledby="admin-title">
        <div className="admin-header">
          <div>
            <p className="admin-kicker">Restricted access</p>
            <h2 id="admin-title">Admin panel</h2>
          </div>
          <button className="admin-close" type="button" onClick={onClose}>Close</button>
        </div>

        {!unlocked ? (
          <form className="admin-login" onSubmit={unlockAdmin}>
            <p>Enter the admin password to edit shop listings, payment methods, and site settings.</p>
            <label className="admin-field">
              Admin password
              <input
                type="password"
                value={password}
                onChange={(event) => setPassword(event.target.value)}
                autoComplete="current-password"
                autoFocus
              />
            </label>
            {error && <p className="admin-error" role="alert">{error}</p>}
            <button className="admin-primary" type="submit">Unlock editing</button>
          </form>
        ) : (
          <>
            <p className="admin-save-note">
              Edits save in this browser only. Server-side authentication is needed for production security and shared updates.
            </p>
            <div className="admin-tabs" role="group" aria-label="Choose listing type">
              <button type="button" aria-pressed={activeTab === "rss"} onClick={() => setActiveTab("rss")}>RSS rates</button>
              <button type="button" aria-pressed={activeTab === "t1"} onClick={() => setActiveTab("t1")}>T1 kills</button>
              <button type="button" aria-pressed={activeTab === "hub"} onClick={() => setActiveTab("hub")}>Hub services</button>
              <button type="button" aria-pressed={activeTab === "payments"} onClick={() => setActiveTab("payments")}>Payment methods</button>
              <button type="button" aria-pressed={activeTab === "site"} onClick={() => setActiveTab("site")}>Site &amp; backgrounds</button>
            </div>

            <div className="admin-content">
              {activeTab === "rss" && (
                <div className="admin-editor-list">
                  {rssTiers.map((tier, tierIndex) => (
                    <section className="admin-group" key={`${tierIndex}-${tier.name}`}>
                      <div className="admin-group-heading">
                        <h3>RSS tier</h3>
                        <button
                          className="admin-remove"
                          type="button"
                          onClick={() => onRssTiersChange(rssTiers.filter((_, index) => index !== tierIndex))}
                        >
                          Remove tier
                        </button>
                      </div>
                      <div className="admin-form-grid">
                        <label className="admin-field">
                          Tier name
                          <input value={tier.name} onChange={(event) => updateRssTier(tierIndex, "name", event.target.value)} />
                        </label>
                        <label className="admin-field">
                          Capacity
                          <input value={tier.capacity} onChange={(event) => updateRssTier(tierIndex, "capacity", event.target.value)} />
                        </label>
                      </div>
                      {tier.offers.map((offer, offerIndex) => (
                        <div className="admin-edit-row" key={`${tierIndex}-${offerIndex}`}>
                          <label className="admin-field">
                            Bundle
                            <input value={offer.bundle} onChange={(event) => updateRssOffer(tierIndex, offerIndex, "bundle", event.target.value)} />
                          </label>
                          <label className="admin-field">
                            Price
                            <input value={offer.price} onChange={(event) => updateRssOffer(tierIndex, offerIndex, "price", event.target.value)} />
                          </label>
                          <button
                            className="admin-remove"
                            type="button"
                            aria-label={`Remove ${offer.bundle} from ${tier.name}`}
                            onClick={() => onRssTiersChange(rssTiers.map((current, index) => index === tierIndex
                              ? { ...current, offers: current.offers.filter((_, itemIndex) => itemIndex !== offerIndex) }
                              : current
                            ))}
                          >
                            Remove
                          </button>
                        </div>
                      ))}
                      <button
                        className="admin-add-row"
                        type="button"
                        onClick={() => onRssTiersChange(rssTiers.map((current, index) => index === tierIndex
                          ? { ...current, offers: [...current.offers, { bundle: "", price: "" }] }
                          : current
                        ))}
                      >
                        + Add RSS option
                      </button>
                    </section>
                  ))}
                  <button
                    className="admin-primary admin-add-group"
                    type="button"
                    onClick={() => onRssTiersChange([...rssTiers, { name: "New tier", capacity: "", offers: [] }])}
                  >
                    Add RSS tier
                  </button>
                </div>
              )}

              {activeTab === "t1" && (
                <div className="admin-editor-list">
                  {t1Services.map((service, serviceIndex) => (
                    <section className="admin-group" key={service.id}>
                      <div className="admin-group-heading">
                        <h3>T1 service</h3>
                        <button
                          className="admin-remove"
                          type="button"
                          onClick={() => onT1ServicesChange(t1Services.filter((_, index) => index !== serviceIndex))}
                        >
                          Remove service
                        </button>
                      </div>
                      <label className="admin-field">
                        Service name
                        <input value={service.type} onChange={(event) => updateT1Service(serviceIndex, event.target.value)} />
                      </label>
                      {service.offers.map((offer, offerIndex) => (
                        <div className="admin-edit-row admin-t1-edit-row" key={`${service.id}-${offerIndex}`}>
                          <label className="admin-field">
                            Amount
                            <input value={offer.amount} onChange={(event) => updateT1Offer(serviceIndex, offerIndex, "amount", event.target.value)} />
                          </label>
                          <label className="admin-field">
                            USD
                            <input value={offer.dollars} onChange={(event) => updateT1Offer(serviceIndex, offerIndex, "dollars", event.target.value)} />
                          </label>
                          <label className="admin-field">
                            INR
                            <input value={offer.inr} onChange={(event) => updateT1Offer(serviceIndex, offerIndex, "inr", event.target.value)} />
                          </label>
                          <button
                            className="admin-remove"
                            type="button"
                            aria-label={`Remove ${offer.amount} T1 package`}
                            onClick={() => onT1ServicesChange(t1Services.map((current, index) => index === serviceIndex
                              ? { ...current, offers: current.offers.filter((_, itemIndex) => itemIndex !== offerIndex) }
                              : current
                            ))}
                          >
                            Remove
                          </button>
                        </div>
                      ))}
                      <button
                        className="admin-add-row"
                        type="button"
                        onClick={() => onT1ServicesChange(t1Services.map((current, index) => index === serviceIndex
                          ? { ...current, offers: [...current.offers, { amount: "", dollars: "", inr: "" }] }
                          : current
                        ))}
                      >
                        + Add T1 package
                      </button>
                    </section>
                  ))}
                  <button
                    className="admin-primary admin-add-group"
                    type="button"
                    onClick={() => onT1ServicesChange([...t1Services, { id: makeId("t1"), type: "New service", offers: [] }])}
                  >
                    Add T1 service
                  </button>
                </div>
              )}

              {activeTab === "hub" && (
                <div className="admin-editor-list">
                  {hubCategories.map((category, categoryIndex) => (
                    <section className="admin-group" key={`${category.id}-${categoryIndex}`}>
                      <div className="admin-group-heading">
                        <label className="admin-field">
                          Category name
                          <input value={category.title} onChange={(event) => updateHubCategory(categoryIndex, event.target.value)} />
                        </label>
                        <button
                          className="admin-remove"
                          type="button"
                          onClick={() => onHubCategoriesChange(hubCategories.filter((_, index) => index !== categoryIndex))}
                        >
                          Remove category
                        </button>
                      </div>
                      {category.items.map((item, itemIndex) => (
                        <div className="admin-edit-row admin-hub-edit-row" key={`${category.id}-${itemIndex}`}>
                          <label className="admin-field">
                            Service or item
                            <input value={item} onChange={(event) => updateHubItem(categoryIndex, itemIndex, event.target.value)} />
                          </label>
                          <button
                            className="admin-remove"
                            type="button"
                            aria-label={`Remove ${item}`}
                            onClick={() => onHubCategoriesChange(hubCategories.map((current, index) => index === categoryIndex
                              ? { ...current, items: current.items.filter((_, currentIndex) => currentIndex !== itemIndex) }
                              : current
                            ))}
                          >
                            Remove
                          </button>
                        </div>
                      ))}
                      <button
                        className="admin-add-row"
                        type="button"
                        onClick={() => onHubCategoriesChange(hubCategories.map((current, index) => index === categoryIndex
                          ? { ...current, items: [...current.items, "New item"] }
                          : current
                        ))}
                      >
                        + Add item
                      </button>
                    </section>
                  ))}
                  <button
                    className="admin-primary admin-add-group"
                    type="button"
                    onClick={() => onHubCategoriesChange([...hubCategories, { id: makeId("category"), title: "New category", items: [] }])}
                  >
                    Add category
                  </button>
                </div>
              )}

              {activeTab === "site" && (
                <div className="admin-editor-list">
                  {SETTING_GROUPS.map((group) => (
                    <section className="admin-group" key={group.title}>
                      <div className="admin-group-heading">
                        <h3>{group.title}</h3>
                      </div>
                      {renderSettingsFields(group.fields)}
                    </section>
                  ))}

                  <section className="admin-group">
                    <div className="admin-group-heading">
                      <h3>Background images</h3>
                    </div>
                    <p className="admin-group-help">Paste a public image URL or upload an image. Uploaded backgrounds are resized for browser storage.</p>
                    <div className="admin-background-list">
                      {BACKGROUND_FIELDS.map(({ key, label }) => (
                        <div className="admin-background-row" key={key}>
                          <label className="admin-field">
                            {label} URL or path
                            <input
                              value={siteSettings.backgrounds[key]}
                              onChange={(event) => updateBackground(key, event.target.value)}
                            />
                          </label>
                          <label className="admin-field admin-file-field">
                            Upload image
                            <input type="file" accept="image/*" onChange={(event) => void uploadBackground(key, event)} />
                          </label>
                          <button className="admin-remove" type="button" onClick={() => updateBackground(key, "")}>Clear</button>
                        </div>
                      ))}
                    </div>
                    <div className="admin-color-settings">
                      <label className="admin-field">
                        Dark theme base color
                        <input
                          type="color"
                          value={siteSettings.backgrounds.darkColor}
                          onChange={(event) => updateBackground("darkColor", event.target.value)}
                        />
                      </label>
                      <label className="admin-field">
                        Bright theme base color
                        <input
                          type="color"
                          value={siteSettings.backgrounds.brightColor}
                          onChange={(event) => updateBackground("brightColor", event.target.value)}
                        />
                      </label>
                    </div>
                    {uploadMessage && <p className="admin-upload-message" role="status">{uploadMessage}</p>}
                  </section>
                </div>
              )}

              {activeTab === "payments" && (
                <div className="admin-editor-list">
                  <section className="admin-group">
                    <div className="admin-group-heading">
                      <h3>Payment section copy</h3>
                    </div>
                    {renderSettingsFields(PAYMENT_SETTING_GROUPS[0].fields)}
                  </section>

                  <section className="admin-group">
                    <div className="admin-group-heading">
                      <h3>UPI</h3>
                      <label className="admin-checkbox">
                        <input
                          type="checkbox"
                          checked={siteSettings.showUpiPayment}
                          onChange={(event) => updatePaymentVisibility("showUpiPayment", event.target.checked)}
                        />
                        Show UPI
                      </label>
                    </div>
                    {renderSettingsFields(PAYMENT_SETTING_GROUPS[1].fields)}
                    <div className="admin-qr-upload">
                      <label className="admin-field admin-file-field">
                        Upload UPI QR image
                        <input type="file" accept="image/*" onChange={(event) => void uploadQrImage(event)} />
                      </label>
                      <button className="admin-remove" type="button" onClick={() => updateSetting("upiQrImage", "")}>Clear QR image</button>
                    </div>
                  </section>

                  <section className="admin-group">
                    <div className="admin-group-heading">
                      <h3>Binance Pay and WhatsApp</h3>
                      <label className="admin-checkbox">
                        <input
                          type="checkbox"
                          checked={siteSettings.showBinancePayment}
                          onChange={(event) => updatePaymentVisibility("showBinancePayment", event.target.checked)}
                        />
                        Show Binance Pay
                      </label>
                    </div>
                    {renderSettingsFields(PAYMENT_SETTING_GROUPS[2].fields)}
                  </section>

                  {uploadMessage && <p className="admin-upload-message" role="status">{uploadMessage}</p>}
                </div>
              )}
            </div>

            <div className="admin-footer-actions">
              <button className="admin-reset" type="button" onClick={confirmReset}>Reset listings</button>
              <button className="admin-lock" type="button" onClick={() => setUnlocked(false)}>Lock panel</button>
            </div>
          </>
        )}
      </aside>
    </div>
  );
}